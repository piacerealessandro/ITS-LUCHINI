Application/User/main.o: \
 C:/Users/Esame/Desktop/Federico/STM/EXTI_ToggleLedOnIT_Init/Src/main.c \
 ../../Inc/main.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_rcc.h \
 ../../Drivers/CMSIS/Device/ST/STM32C0xx/Include/stm32c0xx.h \
 ../../Drivers/CMSIS/Device/ST/STM32C0xx/Include/stm32c031xx.h \
 ../../Drivers/CMSIS/Include/core_cm0plus.h \
 ../../Drivers/CMSIS/Include/cmsis_version.h \
 ../../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../../Drivers/CMSIS/Include/mpu_armv7.h \
 ../../Drivers/CMSIS/Device/ST/STM32C0xx/Include/system_stm32c0xx.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_bus.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_system.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_exti.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_cortex.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_utils.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_pwr.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_dma.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_dmamux.h \
 ../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_gpio.h
../../Inc/main.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_rcc.h:
../../Drivers/CMSIS/Device/ST/STM32C0xx/Include/stm32c0xx.h:
../../Drivers/CMSIS/Device/ST/STM32C0xx/Include/stm32c031xx.h:
../../Drivers/CMSIS/Include/core_cm0plus.h:
../../Drivers/CMSIS/Include/cmsis_version.h:
../../Drivers/CMSIS/Include/cmsis_compiler.h:
../../Drivers/CMSIS/Include/cmsis_gcc.h:
../../Drivers/CMSIS/Include/mpu_armv7.h:
../../Drivers/CMSIS/Device/ST/STM32C0xx/Include/system_stm32c0xx.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_bus.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_system.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_exti.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_cortex.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_utils.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_pwr.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_dma.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_dmamux.h:
../../Drivers/STM32C0xx_HAL_Driver/Inc/stm32c0xx_ll_gpio.h:
